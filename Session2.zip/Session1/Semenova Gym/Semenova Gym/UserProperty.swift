//
//  UserProperty.swift
//  Semenova Gym
//
//  Created by user on 02.03.2021.
//

import Foundation

var weight: String?
var height: String?
